"""
cinema_v1/app.py — Упрощённое веб-приложение кинотеатра
Функционал: расписание сеансов, каталог фильмов, информация о залах, базовая статистика
"""

import sqlite3
import os
from flask import Flask, render_template, request, g

app = Flask(__name__)

DB_PATH = os.path.join(os.path.dirname(__file__), '..', 'кинотеатр.db')


def get_db():
    if 'db' not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON;")
    return g.db


@app.teardown_appcontext
def close_db(e=None):
    db = g.pop('db', None)
    if db:
        db.close()


def _to_iso(col):
    return (f"substr({col},7,4)||'-'||substr({col},4,2)||'-'||substr({col},1,2)"
            f"||' '||substr({col},12,5)")


@app.route('/')
def index():
    db = get_db()

    # Сеансы сегодня
    today_sessions = db.execute(f"""
        SELECT с.код_сеанса, ф.название as фильм, з.название as зал,
               с.начало, с.окончание, с.формат, с.цена_руб,
               ф.возрастной_рейтинг, ф.жанр,
               (SELECT COUNT(*) FROM билеты б WHERE б.код_сеанса = с.код_сеанса
                AND б.статус IN ('оплачен','забронирован')) as занято,
               з.вместимость
        FROM сеансы с
        JOIN фильмы ф ON ф.код_фильма = с.код_фильма
        JOIN залы з ON з.код_зала = с.код_зала
        WHERE substr({_to_iso('с.начало')}, 1, 10) = date('now', 'localtime')
        ORDER BY с.начало
    """).fetchall()

    # Статистика
    stats = {
        'films': db.execute("SELECT COUNT(*) as c FROM фильмы").fetchone()['c'],
        'halls': db.execute("SELECT COUNT(*) as c FROM залы WHERE активен=1").fetchone()['c'],
        'sessions_today': len(today_sessions),
        'tickets_sold': db.execute(
            "SELECT COUNT(*) as c FROM билеты WHERE статус IN ('оплачен','использован')"
        ).fetchone()['c'],
    }

    return render_template('index.html', sessions=today_sessions, stats=stats)


@app.route('/films')
def films():
    db = get_db()
    genre = request.args.get('genre', '')
    rating = request.args.get('rating', '')

    query = """
        SELECT ф.*, COUNT(с.код_сеанса) as сеансов
        FROM фильмы ф
        LEFT JOIN сеансы с ON с.код_фильма = ф.код_фильма
        WHERE 1=1
    """
    params = []
    if genre:
        query += " AND ф.жанр LIKE ?"
        params.append(f"%{genre}%")
    if rating:
        query += " AND ф.возрастной_рейтинг = ?"
        params.append(rating)
    query += " GROUP BY ф.код_фильма ORDER BY сеансов DESC"

    movies = db.execute(query, params).fetchall()
    genres = [r['жанр'] for r in db.execute("SELECT DISTINCT жанр FROM фильмы ORDER BY жанр").fetchall()]
    ratings = ['0+', '6+', '12+', '16+', '18+']

    return render_template('films.html', movies=movies, genres=genres,
                           ratings=ratings, sel_genre=genre, sel_rating=rating)


@app.route('/film/<int:film_id>')
def film_detail(film_id):
    db = get_db()
    film = db.execute("SELECT * FROM фильмы WHERE код_фильма = ?", (film_id,)).fetchone()
    if not film:
        return "Фильм не найден", 404

    sessions = db.execute(f"""
        SELECT с.*, з.название as зал, з.вместимость,
               (SELECT COUNT(*) FROM билеты б WHERE б.код_сеанса = с.код_сеанса
                AND б.статус IN ('оплачен','забронирован')) as занято
        FROM сеансы с
        JOIN залы з ON з.код_зала = с.код_зала
        WHERE с.код_фильма = ?
        AND {_to_iso('с.начало')} >= strftime('%Y-%m-%d %H:%M', 'now', 'localtime')
        ORDER BY с.начало
    """, (film_id,)).fetchall()

    return render_template('film_detail.html', film=film, sessions=sessions)


@app.route('/schedule')
def schedule():
    db = get_db()
    date_filter = request.args.get('date', '')
    film_filter = request.args.get('film', '')
    format_filter = request.args.get('format', '')

    query = f"""
        SELECT с.код_сеанса, ф.название as фильм, ф.код_фильма,
               з.название as зал, с.начало, с.окончание,
               с.формат, с.цена_руб, ф.возрастной_рейтинг, з.вместимость,
               (SELECT COUNT(*) FROM билеты б WHERE б.код_сеанса = с.код_сеанса
                AND б.статус IN ('оплачен','забронирован')) as занято
        FROM сеансы с
        JOIN фильмы ф ON ф.код_фильма = с.код_фильма
        JOIN залы з ON з.код_зала = с.код_зала
        WHERE {_to_iso('с.начало')} >= strftime('%Y-%m-%d %H:%M', 'now', 'localtime')
    """
    params = []
    if date_filter:
        query += f" AND substr({_to_iso('с.начало')}, 1, 10) = ?"
        params.append(date_filter)
    if film_filter:
        query += " AND ф.код_фильма = ?"
        params.append(film_filter)
    if format_filter:
        query += " AND с.формат = ?"
        params.append(format_filter)
    query += " ORDER BY с.начало"

    sessions = db.execute(query, params).fetchall()
    all_films = db.execute("SELECT код_фильма, название FROM фильмы ORDER BY название").fetchall()
    formats = ['2D', '3D', 'IMAX', '4DX']

    return render_template('schedule.html', sessions=sessions, all_films=all_films,
                           formats=formats, date_filter=date_filter,
                           film_filter=film_filter, format_filter=format_filter)


@app.route('/halls')
def halls():
    db = get_db()
    halls_data = db.execute("""
        SELECT з.*,
               COUNT(DISTINCT с.код_сеанса) as сеансов,
               COUNT(м.код_места) as мест_всего
        FROM залы з
        LEFT JOIN сеансы с ON с.код_зала = з.код_зала
        LEFT JOIN места м ON м.код_зала = з.код_зала
        GROUP BY з.код_зала
        ORDER BY з.код_зала
    """).fetchall()
    return render_template('halls.html', halls=halls_data)


@app.route('/stats')
def stats():
    db = get_db()

    popular = db.execute("""
        SELECT ф.название, ф.жанр, COUNT(с.код_сеанса) as сеансов,
               COUNT(б.код_билета) as билетов
        FROM фильмы ф
        LEFT JOIN сеансы с ON с.код_фильма = ф.код_фильма
        LEFT JOIN билеты б ON б.код_сеанса = с.код_сеанса
            AND б.статус IN ('оплачен','использован')
        GROUP BY ф.код_фильма
        ORDER BY сеансов DESC
    """).fetchall()

    hall_fill = db.execute("""
        SELECT з.название, з.вместимость, з.тип_зала,
               COUNT(DISTINCT с.код_сеанса) as сеансов,
               COUNT(б.код_билета) as продано,
               ROUND(100.0 * COUNT(б.код_билета)
                   / NULLIF(з.вместимость * COUNT(DISTINCT с.код_сеанса), 0), 1) as заполняемость
        FROM залы з
        LEFT JOIN сеансы с ON с.код_зала = з.код_зала
        LEFT JOIN билеты б ON б.код_сеанса = с.код_сеанса
            AND б.статус IN ('оплачен','использован')
        WHERE з.активен = 1
        GROUP BY з.код_зала
        ORDER BY заполняемость DESC
    """).fetchall()

    revenue_by_format = db.execute("""
        SELECT с.формат, COUNT(б.код_билета) as билетов,
               ROUND(SUM(б.цена_руб), 2) as выручка
        FROM билеты б
        JOIN сеансы с ON с.код_сеанса = б.код_сеанса
        WHERE б.статус IN ('оплачен','использован')
        GROUP BY с.формат
        ORDER BY выручка DESC
    """).fetchall()

    return render_template('stats.html', popular=popular,
                           hall_fill=hall_fill, revenue_by_format=revenue_by_format)


if __name__ == '__main__':
    app.run(debug=True, port=5001)
