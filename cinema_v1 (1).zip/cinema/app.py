"""
app.py — Flask-приложение
Информационная система кинотеатра (v1 — урезанная)
"""

import sqlite3
import os
from flask import Flask, render_template, g

app = Flask(__name__)
DB_NAME = "кинотеатр.db"


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_NAME)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON;")
    return g.db


@app.teardown_appcontext
def close_db(exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def _to_iso(col):
    return (
        f"substr({col},7,4)||'-'||substr({col},4,2)||'-'||substr({col},1,2)"
        f"||' '||substr({col},12,5)"
    )


# ── Главная страница ──────────────────────────────────────────────────────────
@app.route("/")
def index():
    db = get_db()

    # Сеансы на сегодня
    today_sessions = db.execute(f"""
        SELECT
            с.код_сеанса,
            ф.название  AS фильм,
            ф.возрастной_рейтинг,
            з.название  AS зал,
            с.начало,
            с.окончание,
            с.формат,
            с.цена_руб
        FROM сеансы с
        JOIN фильмы ф ON ф.код_фильма = с.код_фильма
        JOIN залы   з ON з.код_зала   = с.код_зала
        WHERE substr(с.начало,1,10) = strftime('%d.%m.%Y', 'now', 'localtime')
        ORDER BY с.начало
    """).fetchall()

    # Активные сеансы прямо сейчас
    live_sessions = db.execute(f"""
        SELECT с.код_сеанса
        FROM сеансы с
        WHERE strftime('%Y-%m-%d %H:%M', 'now', 'localtime')
              BETWEEN {_to_iso('с.начало')} AND {_to_iso('с.окончание')}
    """).fetchall()
    live_ids = {r["код_сеанса"] for r in live_sessions}

    # Самый популярный фильм
    top_film = db.execute("""
        SELECT ф.название, ф.жанр, ф.год_выпуска, COUNT(с.код_сеанса) AS сеансов
        FROM фильмы ф
        JOIN сеансы с ON с.код_фильма = ф.код_фильма
        GROUP BY ф.код_фильма
        ORDER BY сеансов DESC
        LIMIT 1
    """).fetchone()

    # Зал с наименьшей заполняемостью
    least_hall = db.execute("""
        SELECT
            з.название,
            з.вместимость,
            з.тип_зала,
            COUNT(DISTINCT с.код_сеанса) AS сеансов,
            COUNT(б.код_билета) AS продано,
            ROUND(
                100.0 * COUNT(б.код_билета)
                / NULLIF(з.вместимость * COUNT(DISTINCT с.код_сеанса), 0), 1
            ) AS заполняемость
        FROM залы з
        LEFT JOIN сеансы с ON с.код_зала = з.код_зала
        LEFT JOIN билеты б ON б.код_сеанса = с.код_сеанса
                           AND б.статус IN ('оплачен','использован')
        WHERE з.активен = 1
        GROUP BY з.код_зала
        ORDER BY заполняемость ASC
        LIMIT 1
    """).fetchone()

    return render_template(
        "index.html",
        today_sessions=today_sessions,
        live_ids=live_ids,
        top_film=top_film,
        least_hall=least_hall,
    )


# ── Фильмы ───────────────────────────────────────────────────────────────────
@app.route("/movies")
def movies():
    db = get_db()
    films = db.execute("""
        SELECT
            ф.*,
            COUNT(с.код_сеанса) AS кол_сеансов
        FROM фильмы ф
        LEFT JOIN сеансы с ON с.код_фильма = ф.код_фильма
        GROUP BY ф.код_фильма
        ORDER BY ф.название
    """).fetchall()
    return render_template("movies.html", films=films)


# ── Расписание ────────────────────────────────────────────────────────────────
@app.route("/schedule")
def schedule():
    db = get_db()
    # Получаем сеансы на ближайшие 7 дней, сгруппированные по дате
    rows = db.execute(f"""
        SELECT
            с.код_сеанса,
            substr(с.начало,1,10) AS дата,
            ф.название  AS фильм,
            ф.жанр,
            ф.возрастной_рейтинг,
            ф.длительность_мин,
            з.название  AS зал,
            с.начало,
            с.окончание,
            с.формат,
            с.цена_руб
        FROM сеансы с
        JOIN фильмы ф ON ф.код_фильма = с.код_фильма
        JOIN залы   з ON з.код_зала   = с.код_зала
        WHERE {_to_iso('с.начало')} >= strftime('%Y-%m-%d', 'now', 'localtime')
          AND {_to_iso('с.начало')} <= strftime('%Y-%m-%d', 'now', 'localtime', '+6 days')
        ORDER BY {_to_iso('с.начало')}
    """).fetchall()

    # Группируем по дате
    from collections import OrderedDict
    by_date = OrderedDict()
    for r in rows:
        d = r["дата"]
        by_date.setdefault(d, []).append(r)

    from datetime import datetime as dt
    today_str = dt.now().strftime("%d.%m.%Y")
    return render_template("schedule.html", by_date=by_date, now_str=today_str)


# ── Залы ─────────────────────────────────────────────────────────────────────
@app.route("/halls")
def halls():
    db = get_db()
    halls_list = db.execute("""
        SELECT
            з.*,
            COUNT(DISTINCT с.код_сеанса) AS сеансов_всего,
            COUNT(б.код_билета) AS билетов_продано,
            ROUND(
                100.0 * COUNT(б.код_билета)
                / NULLIF(з.вместимость * COUNT(DISTINCT с.код_сеанса), 0), 1
            ) AS заполняемость
        FROM залы з
        LEFT JOIN сеансы с ON с.код_зала = з.код_зала
        LEFT JOIN билеты б ON б.код_сеанса = с.код_сеанса
                           AND б.статус IN ('оплачен','использован')
        GROUP BY з.код_зала
        ORDER BY з.код_зала
    """).fetchall()
    return render_template("halls.html", halls=halls_list)


# ── Статистика ────────────────────────────────────────────────────────────────
@app.route("/stats")
def stats():
    db = get_db()

    top_films = db.execute("""
        SELECT ф.название, ф.жанр, COUNT(с.код_сеанса) AS сеансов
        FROM фильмы ф
        JOIN сеансы с ON с.код_фильма = ф.код_фильма
        GROUP BY ф.код_фильма
        ORDER BY сеансов DESC
        LIMIT 6
    """).fetchall()

    tickets_by_status = db.execute("""
        SELECT статус, COUNT(*) AS кол_во
        FROM билеты
        GROUP BY статус
    """).fetchall()

    revenue_by_hall = db.execute("""
        SELECT з.название AS зал, SUM(б.цена_руб) AS выручка
        FROM билеты б
        JOIN сеансы с ON с.код_сеанса = б.код_сеанса
        JOIN залы з ON з.код_зала = с.код_зала
        WHERE б.статус IN ('оплачен','использован')
        GROUP BY з.код_зала
        ORDER BY выручка DESC
    """).fetchall()

    total_revenue = db.execute("""
        SELECT SUM(цена_руб) FROM билеты WHERE статус IN ('оплачен','использован')
    """).fetchone()[0] or 0

    total_tickets = db.execute("SELECT COUNT(*) FROM билеты").fetchone()[0]
    total_clients = db.execute("SELECT COUNT(*) FROM клиенты").fetchone()[0]
    total_films   = db.execute("SELECT COUNT(*) FROM фильмы").fetchone()[0]

    return render_template(
        "stats.html",
        top_films=top_films,
        tickets_by_status=tickets_by_status,
        revenue_by_hall=revenue_by_hall,
        total_revenue=total_revenue,
        total_tickets=total_tickets,
        total_clients=total_clients,
        total_films=total_films,
    )


if __name__ == "__main__":
    if not os.path.exists(DB_NAME):
        print(f"ОШИБКА: база данных '{DB_NAME}' не найдена.")
        print("Сначала запустите: python main.py && python seed.py")
    else:
        app.run(debug=True)
