=== CineMax v2 — Расширенная версия ===

Установка и запуск:
  pip install flask
  python app.py
  Открыть: http://localhost:5002

Тестовые учётные записи:
  admin    / admin123    — администратор (полный доступ)
  manager  / manager2024 — менеджер
  cashier1 / cash001     — кассир

Страницы:
  /login        — Авторизация
  /             — Дашборд с KPI
  /schedule     — Расписание + кнопка продажи
  /booking/<id> — Выбор места и оформление билета
  /tickets      — Список всех билетов (отмена, оплата)
  /clients      — CRM клиентов
  /client/<id>  — История покупок клиента
  /employees    — Управление сотрудниками (admin/manager)
  /analytics    — Аналитика: залы, форматы, жанры, топ-клиенты

База данных: кинотеатр.db (SQLite3)
