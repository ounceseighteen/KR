"""
cinema_v2/app.py — Расширенное веб-приложение кинотеатра
Функционал: авторизация, бронирование билетов, CRM клиентов,
управление сотрудниками, аналитический дашборд
"""

import sqlite3
import os
from datetime import datetime
from functools import wraps
from flask import (Flask, render_template, request, g,
                   redirect, url_for, session, flash, jsonify)

app = Flask(__name__)
app.secret_key = 'cinema-secret-key-2024'

DB_PATH = os.path.join(os.path.dirname(__file__), '..', 'кинотеатр.db')


def get_db():
    if 'db' not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON;")
    return g.db


@app.teardown_appcontext
def close_db(e=None):
    db = g.pop('db', None)
    if db:
        db.close()


def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated


def role_required(*roles):
    def decorator(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            if 'user_id' not in session:
                return redirect(url_for('login'))
            if session.get('role') not in roles:
                flash('Недостаточно прав доступа', 'error')
                return redirect(url_for('dashboard'))
            return f(*args, **kwargs)
        return decorated
    return decorator


def _to_iso(col):
    return (f"substr({col},7,4)||'-'||substr({col},4,2)||'-'||substr({col},1,2)"
            f"||' '||substr({col},12,5)")


# ── AUTH ─────────────────────────────────────────────────────────────────────

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        login_ = request.form['login'].strip()
        password = request.form['password'].strip()
        db = get_db()
        user = db.execute(
            "SELECT * FROM сотрудники WHERE логин=? AND пароль=? AND активен=1",
            (login_, password)
        ).fetchone()
        if user:
            session['user_id'] = user['код_сотрудника']
            session['user_name'] = user['полное_имя']
            session['role'] = user['должность']
            flash(f'Добро пожаловать, {user["полное_имя"]}!', 'success')
            return redirect(url_for('dashboard'))
        flash('Неверный логин или пароль', 'error')
    return render_template('login.html')


@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))


# ── DASHBOARD ─────────────────────────────────────────────────────────────────

@app.route('/')
@login_required
def dashboard():
    db = get_db()
    today = datetime.now().strftime('%d.%m.%Y')

    stats = {
        'revenue_total': db.execute(
            "SELECT COALESCE(SUM(цена_руб),0) FROM билеты WHERE статус IN ('оплачен','использован')"
        ).fetchone()[0],
        'tickets_today': db.execute(
            "SELECT COUNT(*) FROM билеты WHERE статус IN ('оплачен','забронирован') AND дата_покупки LIKE ?",
            (f"{today}%",)
        ).fetchone()[0],
        'clients': db.execute("SELECT COUNT(*) FROM клиенты").fetchone()[0],
        'sessions_today': db.execute(
            f"SELECT COUNT(*) FROM сеансы WHERE substr({_to_iso('начало')},1,10)=date('now','localtime')"
        ).fetchone()[0],
        'active_bookings': db.execute(
            "SELECT COUNT(*) FROM билеты WHERE статус='забронирован'"
        ).fetchone()[0],
    }

    # Revenue by payment method
    payment_stats = db.execute("""
        SELECT способ_оплаты, COUNT(*) as кол_во, SUM(цена_руб) as сумма
        FROM билеты WHERE статус IN ('оплачен','использован') AND способ_оплаты IS NOT NULL
        GROUP BY способ_оплаты
    """).fetchall()

    # Top films
    top_films = db.execute("""
        SELECT ф.название, COUNT(б.код_билета) as продано, SUM(б.цена_руб) as выручка
        FROM фильмы ф
        JOIN сеансы с ON с.код_фильма = ф.код_фильма
        JOIN билеты б ON б.код_сеанса = с.код_сеанса
        WHERE б.статус IN ('оплачен','использован')
        GROUP BY ф.код_фильма ORDER BY продано DESC LIMIT 5
    """).fetchall()

    # Status distribution
    status_stats = db.execute("""
        SELECT статус, COUNT(*) as кол_во FROM билеты GROUP BY статус
    """).fetchall()

    # Today sessions quick view
    today_sessions = db.execute(f"""
        SELECT с.*, ф.название as фильм, з.название as зал,
               (SELECT COUNT(*) FROM билеты б WHERE б.код_сеанса=с.код_сеанса
                AND б.статус IN ('оплачен','забронирован')) as занято,
               з.вместимость
        FROM сеансы с
        JOIN фильмы ф ON ф.код_фильма=с.код_фильма
        JOIN залы з ON з.код_зала=с.код_зала
        WHERE substr({_to_iso('с.начало')},1,10)=date('now','localtime')
        ORDER BY с.начало LIMIT 8
    """).fetchall()

    return render_template('dashboard.html', stats=stats, payment_stats=payment_stats,
                           top_films=top_films, status_stats=status_stats,
                           today_sessions=today_sessions)


# ── SCHEDULE & FILMS (read-only, same as v1 but styled differently) ───────────

@app.route('/schedule')
@login_required
def schedule():
    db = get_db()
    date_filter = request.args.get('date', '')
    film_filter = request.args.get('film', '')
    format_filter = request.args.get('format', '')

    query = f"""
        SELECT с.код_сеанса, ф.название as фильм, ф.код_фильма,
               з.название as зал, с.начало, с.окончание,
               с.формат, с.цена_руб, ф.возрастной_рейтинг, з.вместимость,
               (SELECT COUNT(*) FROM билеты б WHERE б.код_сеанса=с.код_сеанса
                AND б.статус IN ('оплачен','забронирован')) as занято
        FROM сеансы с
        JOIN фильмы ф ON ф.код_фильма=с.код_фильма
        JOIN залы з ON з.код_зала=с.код_зала
        WHERE {_to_iso('с.начало')} >= strftime('%Y-%m-%d %H:%M','now','localtime')
    """
    params = []
    if date_filter:
        query += f" AND substr({_to_iso('с.начало')},1,10)=?"
        params.append(date_filter)
    if film_filter:
        query += " AND ф.код_фильма=?"
        params.append(film_filter)
    if format_filter:
        query += " AND с.формат=?"
        params.append(format_filter)
    query += " ORDER BY с.начало"

    sessions_ = db.execute(query, params).fetchall()
    all_films = db.execute("SELECT код_фильма, название FROM фильмы ORDER BY название").fetchall()

    return render_template('schedule.html', sessions=sessions_, all_films=all_films,
                           formats=['2D','3D','IMAX','4DX'],
                           date_filter=date_filter, film_filter=film_filter,
                           format_filter=format_filter)


# ── BOOKING ───────────────────────────────────────────────────────────────────

@app.route('/booking/<int:session_id>')
@login_required
def booking(session_id):
    db = get_db()
    sess = db.execute(f"""
        SELECT с.*, ф.название as фильм, з.название as зал_назв,
               ф.длительность_мин, ф.возрастной_рейтинг, з.вместимость
        FROM сеансы с
        JOIN фильмы ф ON ф.код_фильма=с.код_фильма
        JOIN залы з ON з.код_зала=с.код_зала
        WHERE с.код_сеанса=?
    """, (session_id,)).fetchone()
    if not sess:
        flash('Сеанс не найден', 'error')
        return redirect(url_for('schedule'))

    # Seats with booking status
    seats = db.execute("""
        SELECT м.*, б.статус as занят
        FROM места м
        LEFT JOIN билеты б ON б.код_места=м.код_места AND б.код_сеанса=?
        WHERE м.код_зала=?
        ORDER BY м.ряд, м.номер_места
    """, (session_id, sess['код_зала'])).fetchall()

    clients = db.execute("SELECT код_клиента, полное_имя, телефон FROM клиенты ORDER BY полное_имя").fetchall()

    return render_template('booking.html', sess=sess, seats=seats, clients=clients)


@app.route('/booking/create', methods=['POST'])
@login_required
def create_booking():
    db = get_db()
    session_id = int(request.form['session_id'])
    seat_id = int(request.form['seat_id'])
    client_id = request.form.get('client_id') or None
    payment = request.form.get('payment') or None
    status = request.form.get('status', 'забронирован')

    # Check seat availability
    existing = db.execute(
        "SELECT 1 FROM билеты WHERE код_сеанса=? AND код_места=? AND статус != 'отменён'",
        (session_id, seat_id)
    ).fetchone()
    if existing:
        flash('Это место уже занято', 'error')
        return redirect(url_for('booking', session_id=session_id))

    # Get price from session
    price = db.execute("SELECT цена_руб FROM сеансы WHERE код_сеанса=?", (session_id,)).fetchone()['цена_руб']
    now = datetime.now().strftime('%d.%m.%Y %H:%M')

    db.execute("""
        INSERT INTO билеты (код_сеанса, код_места, код_клиента, цена_руб, статус, дата_покупки, способ_оплаты)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (session_id, seat_id, client_id, price, status, now, payment))

    # Award bonus points
    if client_id and status == 'оплачен':
        bonus = int(price * 0.05)
        db.execute("UPDATE клиенты SET бонусные_баллы = бонусные_баллы + ? WHERE код_клиента=?",
                   (bonus, client_id))

    db.commit()
    flash('Билет успешно оформлен!', 'success')
    return redirect(url_for('booking', session_id=session_id))


@app.route('/tickets')
@login_required
def tickets():
    db = get_db()
    status_f = request.args.get('status', '')
    search = request.args.get('search', '')
    page = int(request.args.get('page', 1))
    per_page = 20

    query = """
        SELECT б.*, с.начало, ф.название as фильм, з.название as зал,
               м.ряд, м.номер_места, к.полное_имя as клиент
        FROM билеты б
        JOIN сеансы с ON с.код_сеанса=б.код_сеанса
        JOIN фильмы ф ON ф.код_фильма=с.код_фильма
        JOIN залы з ON з.код_зала=с.код_зала
        JOIN места м ON м.код_места=б.код_места
        LEFT JOIN клиенты к ON к.код_клиента=б.код_клиента
        WHERE 1=1
    """
    params = []
    if status_f:
        query += " AND б.статус=?"; params.append(status_f)
    if search:
        query += " AND (ф.название LIKE ? OR к.полное_имя LIKE ?)"; params += [f'%{search}%']*2

    total = db.execute(f"SELECT COUNT(*) FROM ({query})", params).fetchone()[0]
    query += f" ORDER BY б.дата_покупки DESC LIMIT {per_page} OFFSET {(page-1)*per_page}"
    tickets_ = db.execute(query, params).fetchall()

    return render_template('tickets.html', tickets=tickets_, status_f=status_f,
                           search=search, page=page, per_page=per_page, total=total)


@app.route('/ticket/<int:ticket_id>/cancel', methods=['POST'])
@login_required
def cancel_ticket(ticket_id):
    db = get_db()
    db.execute("UPDATE билеты SET статус='отменён' WHERE код_билета=?", (ticket_id,))
    db.commit()
    flash('Билет отменён', 'success')
    return redirect(request.referrer or url_for('tickets'))


@app.route('/ticket/<int:ticket_id>/paid', methods=['POST'])
@login_required
def mark_paid(ticket_id):
    db = get_db()
    t = db.execute("SELECT * FROM билеты WHERE код_билета=?", (ticket_id,)).fetchone()
    if t:
        db.execute("UPDATE билеты SET статус='оплачен', способ_оплаты=? WHERE код_билета=?",
                   (request.form.get('payment','карта'), ticket_id))
        if t['код_клиента']:
            bonus = int(t['цена_руб'] * 0.05)
            db.execute("UPDATE клиенты SET бонусные_баллы=бонусные_баллы+? WHERE код_клиента=?",
                       (bonus, t['код_клиента']))
        db.commit()
        flash('Билет оплачен', 'success')
    return redirect(request.referrer or url_for('tickets'))


# ── CRM CLIENTS ───────────────────────────────────────────────────────────────

@app.route('/clients')
@login_required
def clients():
    db = get_db()
    search = request.args.get('search', '')
    query = """
        SELECT к.*, COUNT(б.код_билета) as билетов,
               COALESCE(SUM(б.цена_руб), 0) as потрачено
        FROM клиенты к
        LEFT JOIN билеты б ON б.код_клиента=к.код_клиента AND б.статус IN ('оплачен','использован')
        WHERE 1=1
    """
    params = []
    if search:
        query += " AND (к.полное_имя LIKE ? OR к.электронная_почта LIKE ? OR к.телефон LIKE ?)"
        params += [f'%{search}%']*3
    query += " GROUP BY к.код_клиента ORDER BY потрачено DESC"
    clients_ = db.execute(query, params).fetchall()
    return render_template('clients.html', clients=clients_, search=search)


@app.route('/client/<int:client_id>')
@login_required
def client_detail(client_id):
    db = get_db()
    client = db.execute("SELECT * FROM клиенты WHERE код_клиента=?", (client_id,)).fetchone()
    if not client:
        flash('Клиент не найден', 'error')
        return redirect(url_for('clients'))

    history = db.execute("""
        SELECT б.*, ф.название as фильм, с.начало, з.название as зал,
               м.ряд, м.номер_места
        FROM билеты б
        JOIN сеансы с ON с.код_сеанса=б.код_сеанса
        JOIN фильмы ф ON ф.код_фильма=с.код_фильма
        JOIN залы з ON з.код_зала=с.код_зала
        JOIN места м ON м.код_места=б.код_места
        WHERE б.код_клиента=?
        ORDER BY б.дата_покупки DESC
    """, (client_id,)).fetchall()

    return render_template('client_detail.html', client=client, history=history)


@app.route('/clients/add', methods=['GET', 'POST'])
@login_required
def add_client():
    if request.method == 'POST':
        db = get_db()
        now = datetime.now().strftime('%d.%m.%Y')
        try:
            db.execute("""
                INSERT INTO клиенты (полное_имя, электронная_почта, телефон, бонусные_баллы, дата_регистрации)
                VALUES (?, ?, ?, 0, ?)
            """, (request.form['name'], request.form.get('email') or None,
                  request.form.get('phone') or None, now))
            db.commit()
            flash('Клиент добавлен', 'success')
            return redirect(url_for('clients'))
        except sqlite3.IntegrityError:
            flash('Email уже зарегистрирован', 'error')
    return render_template('add_client.html')


# ── EMPLOYEES ─────────────────────────────────────────────────────────────────

@app.route('/employees')
@role_required('администратор', 'менеджер')
def employees():
    db = get_db()
    emps = db.execute("SELECT * FROM сотрудники ORDER BY активен DESC, полное_имя").fetchall()
    return render_template('employees.html', employees=emps)


@app.route('/employees/add', methods=['GET', 'POST'])
@role_required('администратор')
def add_employee():
    if request.method == 'POST':
        db = get_db()
        now = datetime.now().strftime('%d.%m.%Y')
        try:
            db.execute("""
                INSERT INTO сотрудники (полное_имя, должность, логин, пароль, дата_найма, активен)
                VALUES (?, ?, ?, ?, ?, 1)
            """, (request.form['name'], request.form['role'],
                  request.form['login'], request.form['password'], now))
            db.commit()
            flash('Сотрудник добавлен', 'success')
            return redirect(url_for('employees'))
        except sqlite3.IntegrityError:
            flash('Логин уже занят', 'error')
    return render_template('add_employee.html')


@app.route('/employee/<int:emp_id>/toggle', methods=['POST'])
@role_required('администратор')
def toggle_employee(emp_id):
    db = get_db()
    db.execute("UPDATE сотрудники SET активен = 1 - активен WHERE код_сотрудника=?", (emp_id,))
    db.commit()
    flash('Статус сотрудника изменён', 'success')
    return redirect(url_for('employees'))


# ── ANALYTICS ─────────────────────────────────────────────────────────────────

@app.route('/analytics')
@login_required
def analytics():
    db = get_db()

    hall_fill = db.execute("""
        SELECT з.название, з.вместимость, з.тип_зала,
               COUNT(DISTINCT с.код_сеанса) as сеансов,
               COUNT(б.код_билета) as продано,
               ROUND(100.0*COUNT(б.код_билета)/NULLIF(з.вместимость*COUNT(DISTINCT с.код_сеанса),0),1) as fill_pct
        FROM залы з
        LEFT JOIN сеансы с ON с.код_зала=з.код_зала
        LEFT JOIN билеты б ON б.код_сеанса=с.код_сеанса AND б.статус IN ('оплачен','использован')
        WHERE з.активен=1 GROUP BY з.код_зала ORDER BY fill_pct DESC
    """).fetchall()

    top_clients = db.execute("""
        SELECT к.полное_имя, к.бонусные_баллы, COUNT(б.код_билета) as билетов,
               COALESCE(SUM(б.цена_руб),0) as потрачено
        FROM клиенты к
        LEFT JOIN билеты б ON б.код_клиента=к.код_клиента AND б.статус IN ('оплачен','использован')
        GROUP BY к.код_клиента ORDER BY потрачено DESC LIMIT 8
    """).fetchall()

    revenue_format = db.execute("""
        SELECT с.формат, COUNT(б.код_билета) as cnt, SUM(б.цена_руб) as rev
        FROM билеты б JOIN сеансы с ON с.код_сеанса=б.код_сеанса
        WHERE б.статус IN ('оплачен','использован')
        GROUP BY с.формат ORDER BY rev DESC
    """).fetchall()

    genre_dist = db.execute("""
        SELECT ф.жанр, COUNT(б.код_билета) as cnt
        FROM фильмы ф
        JOIN сеансы с ON с.код_фильма=ф.код_фильма
        JOIN билеты б ON б.код_сеанса=с.код_сеанса
        WHERE б.статус IN ('оплачен','использован')
        GROUP BY ф.жанр ORDER BY cnt DESC
    """).fetchall()

    return render_template('analytics.html', hall_fill=hall_fill, top_clients=top_clients,
                           revenue_format=revenue_format, genre_dist=genre_dist)


# ── API (JSON) ────────────────────────────────────────────────────────────────

@app.route('/api/session-seats/<int:session_id>')
@login_required
def api_session_seats(session_id):
    db = get_db()
    seats = db.execute("""
        SELECT м.код_места, м.ряд, м.номер_места, м.тип_места, б.статус as занят
        FROM места м
        LEFT JOIN билеты б ON б.код_места=м.код_места AND б.код_сеанса=?
        WHERE м.код_зала=(SELECT код_зала FROM сеансы WHERE код_сеанса=?)
        ORDER BY м.ряд, м.номер_места
    """, (session_id, session_id)).fetchall()
    return jsonify([dict(s) for s in seats])


if __name__ == '__main__':
    app.run(debug=True, port=5002)
